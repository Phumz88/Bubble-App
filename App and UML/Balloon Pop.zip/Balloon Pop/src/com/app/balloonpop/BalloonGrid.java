package com.app.balloonpop;

/*
 *It keeps track of the number of poppedBubbles * 
 * 
 * @author Phumudzo Vusani Neluheni
 */
public class BalloonGrid {

	private int numberOfBalloons;
	private int poppedBalloons;
	private Integer[] balloons; //1dArray of balloons

	/*
	 *Creates Grid of Balloons (Unpopped Balloons)
	 */
	public BalloonGrid(int numberOfBallons, int balloon) {
		this.numberOfBalloons = numberOfBallons;
		this.poppedBalloons = 0;
		this.balloons = new Integer[numberOfBalloons];
		for (int i = 0; i < numberOfBalloons; i++) {
			balloons[i] = balloon;
		}

	}
	//Returns index of popped balloons
	public void popBalloon(int index, int balloon) {

		balloons[index] = balloon;
		poppedBalloons++;
	}

	/*
	 * @Returns Number Of Popped Balloons
	 */
	public int getNumberOfPoppedBalloons() {
		return poppedBalloons;
	}

	/*
	 * @Returns Number Of Unpopped Balloons
	 */
	public int getNumberOfBalloons() {
		return numberOfBalloons;
	}

	/*
	 * @return the balloons
	 */
	public Integer[] getBalloons() {
		return balloons;

	}

	//Index Of Balloon. Return true if the Balloon is not popped 
	public boolean isBubble(int index, int balloon) {
		if (balloons[index] == balloon) {
			return true;
		}
		return false;
	}

}
